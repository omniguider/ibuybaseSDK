package com.omni.ibuybase.tool;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.google.gson.Gson;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class PreferencesTools {

    private static final String KEY_NMP_PREFERENCES_NAME = "key_preferences_nmp_preferences_name";
    public static final String KEY_ALL_BUILDINGS = "key_preferences_all_buildings";
    public static final String KEY_FLOORS = "key_preferences_floors";
    public static final String KEY_EXHIBIT_FLOORS = "key_preferences_exhibit_floors";
    public static final String KEY_EXHIBIT_THEMES = "key_preferences_exhibit_themes";
    public static final String KEY_BEACON_NOTIFICATION_HISTORY = "key_preferences_beacon_notification_history";
    public static final String KEY_BEACON_NOTIFICATION_HISTORY_UNREAD = "key_preferences_beacon_notification_history_unread";
    public static final String KEY_GEO_FENCE_NOTIFICATION_HISTORY = "key_preferences_geo_fence_notification_history";
    public static final String KEY_GEO_FENCE_NOTIFICATION_HISTORY_UNREAD = "key_preferences_geo_fence_notification_history_unread";
    public static final String KEY_RECORDED_CAR_LOCATION = "key_preferences_recorded_car_location";
    public static final String KEY_PARKING_SPACE_INFO = "key_preferences_parking_space_info";
    public static final String KEY_PRIVACY = "key_preferences_privacy";
    public static final String KEY_PICKUP = "key_preferences_pickup";
    public static final String KEY_XDAY = "key_preferences_xday";

    private static PreferencesTools mPreferencesTools;
    private Gson mGson;

    public static PreferencesTools getInstance() {
        if (mPreferencesTools == null) {
            mPreferencesTools = new PreferencesTools();
        }
        return mPreferencesTools;
    }

    public Gson getGson() {
        if (mGson == null) {
            mGson = new Gson();
        }
        return mGson;
    }

    private SharedPreferences getPreferences(Context context) {
        if (context != null)
            return context.getSharedPreferences(KEY_NMP_PREFERENCES_NAME, Context.MODE_PRIVATE);
        return null;
    }

    public void removePreviousDaysBeaconProperty(Context context, String key, String dateStr) {
        SharedPreferences preferences = getPreferences(context);
        Map<String, ?> map = preferences.getAll();
        for (String k : map.keySet()) {
            if (k.contains(key) && !k.equals(key + dateStr)) {
                removeProperty(context, k);
            }
        }
    }

    public void saveProperty(Context context, String name, String value) {
        SharedPreferences.Editor e = getPreferences(context).edit();
        e.putString(name, value);
        e.apply();
    }

    public <T> void saveProperty(Context context, String name, T value) {
        SharedPreferences.Editor e = getPreferences(context).edit();
        e.putString(name, getGson().toJson(value));
        e.apply();
    }

    public void removeProperty(Context context, String name) {
        SharedPreferences.Editor e = getPreferences(context).edit();
        e.remove(name);
        e.apply();
    }

    public String getProperty(Context context, String name, String def) {
        return getPreferences(context).getString(name, def);
    }

    @Nullable
    public String getProperty(Context context, String name) {
        if (getPreferences(context)!=null) {
            return getPreferences(context).getString(name, null);
        }else{
            return null;
        }
    }

    @Nullable
    public <T> T getProperty(Context context, String name, Class<T> c) {
        String valueStr = getProperty(context, name);
        if (valueStr != null) {
            return getGson().fromJson(valueStr, c);
        }
        return null;
    }

    @NonNull
    public <T, X> Map getProperties(Context context, String name, Type type,
                                    Class<T> keyClass, Class<X> valueClass) {
        String valueStr = getProperty(context, name);
        Map<T, X> map;
        if (valueStr == null) {
            map = new HashMap<>();
        } else {
            map = getGson().fromJson(valueStr, type);
        }

        return map;
    }

    @Nullable
    public Set<String> getProperties(Context context, String name) {
        return getProperties(context, name, null);
    }

    @Nullable
    public Set<String> getProperties(Context context, String name, Set<String> def) {
        return getPreferences(context).getStringSet(name, def);
    }

    public void saveProperties(Context context, String name, Set<String> values) {
        SharedPreferences.Editor e = getPreferences(context).edit();
        e.putStringSet(name, values);
        e.apply();
    }

    public void addProperties(Context context, String name, String value) {
        Set<String> previousSet = getPreferences(context).getStringSet(name, null);
        Set<String> set;
        if (previousSet == null) {
            set = new HashSet<>();
        } else {
            set = new HashSet<>(previousSet);
        }

        if (!set.contains(value)) {
            set.add(value);
        }

        saveProperties(context, name, set);
    }

    public <T, X> boolean addProperties(Context context, String name, HashMap<T, X> newMap) {
        String valueStr = getProperty(context, name);
        HashMap<T, X> previousMap;
        if (TextUtils.isEmpty(valueStr)) {
            previousMap = new HashMap<>();
        } else {
            previousMap = getGson().fromJson(valueStr, newMap.getClass());
        }

        boolean haveNewKey = false;

        for (T key : newMap.keySet()) {
            if (!previousMap.containsKey(key)) {
                haveNewKey = true;
                break;
            }
        }

        newMap.keySet().removeAll(previousMap.keySet());
        previousMap.putAll(newMap);

        saveProperty(context, name, previousMap);

        return haveNewKey;
    }
}
