package com.omni.ibuybase.view.user;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.omni.ibuybase.R;
import com.omni.ibuybase.manager.AnimationFragmentManager;
import com.omni.ibuybase.manager.UserInfoManager;
import com.omni.ibuybase.module.OmniEvent;
import com.omni.ibuybase.module.user.LoginData;
import com.omni.ibuybase.network.NetworkManager;
import com.omni.ibuybase.network.api.IBuyBaseAPI;
import com.omni.ibuybase.tool.AeSimpleSHA1;
import com.omni.ibuybase.tool.DialogTools;
import com.omni.ibuybase.view.OmniEditText;

import org.greenrobot.eventbus.EventBus;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

import static com.omni.ibuybase.tool.IBuyBaseText.LOG_TAG;

public class LoginFragment extends Fragment {

    public static final String TAG = "fragment_tag_login";
    int RC_BARCODE_CAPTURE = 9001;
    int RC_QRCODE_CAPTURE = 9002;

    private Context mContext;
    private View mView;
    private LinearLayout mLoginLayoutLL;
    private LinearLayout mLogoutLayoutLL;
    private OmniEditText mAccountOET;
    private OmniEditText mPasswordOET;
    private TextView mLoginTV;
    private TextView mLogoutTV;

    public static LoginFragment newInstance() {
        LoginFragment fragment = new LoginFragment();

        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mView = inflater.inflate(R.layout.fragment_login, container, false);

        mView.findViewById(R.id.fragment_login_fl_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });

        mLoginLayoutLL = mView.findViewById(R.id.fragment_login_ll_login_layout);

        mAccountOET = mView.findViewById(R.id.fragment_login_oet_account);
        mAccountOET.setOmniEditTextListener(new OmniEditText.OmniEditTextListener() {
            @Override
            public void onSoftKeyboardDismiss() {
                setFocusOnFragment();
            }

            @Override
            public void onTouch(MotionEvent event) {
            }
        });

        mPasswordOET = mView.findViewById(R.id.fragment_login_oet_password);
        mPasswordOET.setOmniEditTextListener(new OmniEditText.OmniEditTextListener() {
            @Override
            public void onSoftKeyboardDismiss() {
                setFocusOnFragment();
            }

            @Override
            public void onTouch(MotionEvent event) {

            }
        });

        mLoginTV = mView.findViewById(R.id.fragment_login_tv_login);
        mLoginTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String account = mAccountOET.getText().toString().trim();
                String password = mPasswordOET.getText().toString().trim();
                String passwordEncrypt = password;
                try {
                    passwordEncrypt = AeSimpleSHA1.SHA1("omoapp://" + password);
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }

                if (TextUtils.isEmpty(account)) {
                    mAccountOET.setError(getString(R.string.input_required));
                } else if (TextUtils.isEmpty(password)) {
                    mPasswordOET.setError(getString(R.string.input_required));
                } else {
                    IBuyBaseAPI.getInstance().login(getActivity(),
                            account,
                            passwordEncrypt,
                            new NetworkManager.NetworkManagerListener<LoginData>() {
                                @Override
                                public void onSucceed(LoginData data) {
                                    UserInfoManager.getInstance().saveUserLoginInfo(getActivity(), data);
                                    showLoginSuccessDialog();
                                    EventBus.getDefault().post(new OmniEvent(OmniEvent.TYPE_LOGIN_STATUS_CHANGED, ""));
                                    hideKeyboard(getActivity());
                                }

                                @Override
                                public void onFail(String errorMsg, boolean shouldRetry) {
                                    DialogTools.getInstance().showErrorMessage(getActivity(), R.string.error_dialog_title_text_normal, errorMsg);
                                }
                            });
                }
            }
        });

        return mView;
    }


    private void setFocusOnFragment() {
        mView.setFocusableInTouchMode(true);
        mView.requestFocus();
    }

    private void showLoginSuccessDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext)
                .setTitle(R.string.login_page_dialog_message_login_successful)
                .setPositiveButton(R.string.dialog_button_ok_text, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getActivity().getSupportFragmentManager().popBackStack();
                    }
                });

        builder.create().show();
    }

    private void openFragmentPage(Fragment fragment, String tag) {
        AnimationFragmentManager.getInstance().replaceFragmentPage(getActivity(),
                R.id.fragment_login_main_fl,
                fragment,
                tag);
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
