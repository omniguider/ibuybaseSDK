package com.omni.ibuybase.view;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.omni.ibuybase.R;
import com.omni.ibuybase.tool.IBuyBaseText;

public class LearningFragment extends Fragment {

    public static final String TAG = "fragment_tag_learning";

    private View mView;

    public static LearningFragment newInstance() {
        LearningFragment fragment = new LearningFragment();

        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        if (mView == null) {
            mView = inflater.inflate(R.layout.fragment_learning, container, false);

            mView.findViewById(R.id.fragment_learning_fl_back).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getActivity().getSupportFragmentManager().popBackStack();
                }
            });

            mView.findViewById(R.id.fragment_learning_video_1_iv).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), YoutubePlayerActivity.class);
                    intent.putExtra(IBuyBaseText.KEY_YOUTUBE_VIDEO_ID, "gwEufDnvKoA");
                    intent.putExtra(IBuyBaseText.KEY_YOUTUBE_TITLE, getResources().getString(R.string.fragment_home_recommend_learning));
                    startActivity(intent);
                }
            });

            mView.findViewById(R.id.fragment_learning_video_2_iv).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), YoutubePlayerActivity.class);
                    intent.putExtra(IBuyBaseText.KEY_YOUTUBE_VIDEO_ID, "E_7La-iETjU");
                    intent.putExtra(IBuyBaseText.KEY_YOUTUBE_TITLE, getResources().getString(R.string.fragment_home_recommend_learning));
                    startActivity(intent);
                }
            });

            mView.findViewById(R.id.fragment_learning_video_3_iv).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(), YoutubePlayerActivity.class);
                    intent.putExtra(IBuyBaseText.KEY_YOUTUBE_VIDEO_ID, "VzSGb65VyPs");
                    intent.putExtra(IBuyBaseText.KEY_YOUTUBE_TITLE, getResources().getString(R.string.fragment_home_recommend_learning));
                    startActivity(intent);
                }
            });
        }

        return mView;
    }
}
