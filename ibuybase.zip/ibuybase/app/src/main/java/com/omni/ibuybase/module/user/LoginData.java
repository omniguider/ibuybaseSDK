package com.omni.ibuybase.module.user;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class LoginData implements Serializable {

    @SerializedName("account")
    private String account;
    @SerializedName("login_token")
    private String login_token;
    @SerializedName("name")
    private String name;
    @SerializedName("nickname")
    private String nickname;
    @SerializedName("bonus")
    private String bonus;
    @SerializedName("bonus_url")
    private String bonus_url;
    @SerializedName("quota")
    private String quota;
    @SerializedName("quota_url")
    private String quota_url;
    @SerializedName("order_num")
    private int order_num;
    @SerializedName("order_url")
    private String order_url;

    private LoginData() {

    }

    public String getAccount() {
        return account;
    }

    private void setAccount(String account) {
        this.account = account;
    }

    public String getLogin_token() {
        return login_token;
    }

    private void setLogin_token(String login_token) {
        this.login_token = login_token;
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getNickname() {
        return nickname;
    }

    private void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getBonus() {
        return bonus;
    }

    private void setBonus(String bonus) {
        this.bonus = bonus;
    }

    public String getBonus_url() {
        return bonus_url;
    }

    private void setBonus_url(String bonus_url) {
        this.bonus_url = bonus_url;
    }

    public String getQuota() {
        return quota;
    }

    private void setQuota(String quota) {
        this.quota = quota;
    }

    public String getQuota_url() {
        return quota_url;
    }

    private void setQuota_url(String quota_url) {
        this.quota_url = quota_url;
    }

    public int getOrder_num() {
        return order_num;
    }

    private void setOrder_num(int order_num) {
        this.order_num = order_num;
    }

    public String getOrder_url() {
        return order_url;
    }

    private void setOrder_url(String order_url) {
        this.order_url = order_url;
    }

    public static class Builder {

        private LoginData mLoginData;

        public Builder() {
            mLoginData = new LoginData();
        }

        public Builder setAccount(String account) {
            mLoginData.setAccount(account);
            return this;
        }

        public Builder setLogin_token(String login_token) {
            mLoginData.setLogin_token(login_token);
            return this;
        }

        public Builder setName(String name) {
            mLoginData.setName(name);
            return this;
        }

        public Builder setNickname(String nickname) {
            mLoginData.setNickname(nickname);
            return this;
        }

        public Builder setBonus(String bonus) {
            mLoginData.setBonus(bonus);
            return this;
        }

        public Builder setBonus_url(String bonus_url) {
            mLoginData.setBonus_url(bonus_url);
            return this;
        }

        public Builder setQuota(String quota) {
            mLoginData.setQuota(quota);
            return this;
        }

        public Builder setQuota_url(String quota_url) {
            mLoginData.setQuota_url(quota_url);
            return this;
        }

        public Builder setOrder_num(int order_num) {
            mLoginData.setOrder_num(order_num);
            return this;
        }

        public Builder setOrder_url(String order_url) {
            mLoginData.setOrder_url(order_url);
            return this;
        }
    }

}
