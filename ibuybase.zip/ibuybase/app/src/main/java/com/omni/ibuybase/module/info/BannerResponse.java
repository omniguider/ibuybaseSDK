package com.omni.ibuybase.module.info;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class BannerResponse implements Serializable {

    @SerializedName("result")
    private String result;
    @SerializedName("error_message")
    private String errorMessage;
    @SerializedName("data")
    private BannerData[] data;
    @SerializedName("notice")
    private String[] notice;

    public String getResult() {
        return result;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public BannerData[] getData() {
        return data;
    }

    public String[] getNotice() {
        return notice;
    }

}