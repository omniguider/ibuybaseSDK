package com.omni.ibuybase.view;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.omni.ibuybase.R;
import com.omni.ibuybase.tool.IBuyBaseText;

import static com.omni.ibuybase.tool.IBuyBaseText.LOG_TAG;

public class YoutubePlayerActivity extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener {

    private String title;
    private String video_id;
    private YouTubePlayerView mYoutubePlayerView;
    public static final String API_KEY = "AIzaSyCtsbLjTBGIDJV69W9YWzyf0gXtA0B4WX4";

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_youtube_player);

        findViewById(R.id.activity_youtube_player_fl_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    finish();
            }
        });

        Intent intent = getIntent();
        title = intent.getStringExtra(IBuyBaseText.KEY_YOUTUBE_TITLE);
        video_id = intent.getStringExtra(IBuyBaseText.KEY_YOUTUBE_VIDEO_ID);
        mYoutubePlayerView = findViewById(R.id.player_view);
        mYoutubePlayerView.initialize(API_KEY, this);

        ((TextView) findViewById(R.id.activity_youtube_player_fl_action_bar_title)).setText(title);

    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean wasRestored) {
        if (youTubePlayer == null) {
            Log.e(LOG_TAG, "youtubePlayer == null");
            return;
        }

        if (!wasRestored) {
            Log.e(LOG_TAG, "!wasRestored" + video_id);
            youTubePlayer.setPlayerStyle(YouTubePlayer.PlayerStyle.MINIMAL);
            youTubePlayer.loadVideo(video_id);
        }
    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

    }
}
