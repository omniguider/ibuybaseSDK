package com.omni.ibuybase.module.info;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class BannerData implements Serializable {

    @SerializedName("image")
    private String image;
    @SerializedName("url")
    private String url;

    public String getImage() {
        return image;
    }

    public String getUrl() {
        return url;
    }

}
