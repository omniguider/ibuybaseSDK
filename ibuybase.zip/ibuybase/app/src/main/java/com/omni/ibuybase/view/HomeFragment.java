package com.omni.ibuybase.view;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.toolbox.NetworkImageView;
import com.omni.ibuybase.R;
import com.omni.ibuybase.manager.AnimationFragmentManager;
import com.omni.ibuybase.manager.UserInfoManager;
import com.omni.ibuybase.module.OmniEvent;
import com.omni.ibuybase.module.info.BannerResponse;
import com.omni.ibuybase.module.user.LogoutResponse;
import com.omni.ibuybase.network.NetworkManager;
import com.omni.ibuybase.network.api.IBuyBaseAPI;
import com.omni.ibuybase.tool.DialogTools;
import com.omni.ibuybase.tool.IBuyBaseText;
import com.omni.ibuybase.view.user.LoginFragment;
import com.omni.y5citysdk.Y5CitySDKActivity;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;


public class HomeFragment extends Fragment {

    private int RC_BARCODE_CAPTURE = 9001;

    private static final String ARG_KEY_USER_ID = "arg_key_user_id";
    private static final String ARG_KEY_USER_NAME = "arg_key_user_name";
    private static final String ARG_KEY_PROJECT_ID = "arg_key_project_id";
    private static final String ARG_KEY_TYPE = "arg_key_type";

    private View mView;
    private ViewPager infoImageViewPager;
    private TabLayout infoImageTableLayout;
    private PicPagerAdapter mPicPagerAdapter;
    private DrawerLayout drawerLayout;

    private EventBus mEventBus;
    private TextView logInOut;
    private TextView notify_tv;
    private TextView quota_tv;
    private TextView bouns_tv;
    private TextView order_tv;

    private Handler mTimeHandler;
    private int mCountTime = 0;
    private int mPicVPIndex = 0;
    private Runnable timerRun = new Runnable() {
        @Override
        public void run() {
            ++mCountTime;
            if (mCountTime == 3 && infoImageViewPager != null) {
                mCountTime = 0;
                mPicVPIndex = infoImageViewPager.getCurrentItem();
                if (mPicPagerAdapter != null) {
                    if (mPicVPIndex < mPicPagerAdapter.getCount() - 1) {
                        mPicVPIndex++;
                    } else {
                        mPicVPIndex = 0;
                    }
                    infoImageViewPager.setCurrentItem(mPicVPIndex, true);
                }
            }
            mTimeHandler.removeCallbacks(this);
            mTimeHandler.postDelayed(this, 1000);
        }
    };

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(OmniEvent event) {
        switch (event.getType()) {
            case OmniEvent.TYPE_LOGIN_STATUS_CHANGED:
                if (UserInfoManager.getInstance().isLoggedIn(getActivity())) {
                    logInOut.setText(getString(R.string.fragment_home_menu_logout));
                    quota_tv.setText(UserInfoManager.getInstance().getUserInfo(getActivity()).getQuota());
                    bouns_tv.setText(UserInfoManager.getInstance().getUserInfo(getActivity()).getBonus());
                    order_tv.setText(String.valueOf(UserInfoManager.getInstance().getUserInfo(getActivity()).getOrder_num()));
                } else {
                    logInOut.setText(getString(R.string.fragment_home_menu_login));
                    quota_tv.setText("0");
                    bouns_tv.setText("0");
                    order_tv.setText("0");
                }
                break;
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (mTimeHandler == null) {
            mTimeHandler = new Handler();
            mTimeHandler.postDelayed(timerRun, 3000);
        }
        if (mEventBus == null) {
            mEventBus = EventBus.getDefault();
        }
        mEventBus.register(this);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mTimeHandler != null && timerRun != null) {
            mTimeHandler.removeCallbacks(timerRun);
        }
        if (mEventBus != null) {
            mEventBus.unregister(this);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (notify_tv != null) {
            notify_tv.setSelected(true);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        if (mView == null) {

            mView = inflater.inflate(R.layout.fragment_home, container, false);

            infoImageViewPager = mView.findViewById(R.id.fragment_home_vp_pic);
            infoImageTableLayout = mView.findViewById(R.id.fragment_home_tl);

            IBuyBaseAPI.getInstance().getBanner(getActivity(), new NetworkManager.NetworkManagerListener<BannerResponse>() {
                @Override
                public void onSucceed(BannerResponse bannerResponse) {
                    String[] bannerImg = new String[bannerResponse.getData().length];
                    String[] bannerUrl = new String[bannerResponse.getData().length];
                    for (int i = 0; i < bannerResponse.getData().length; i++) {
                        bannerImg[i] = bannerResponse.getData()[i].getImage();
                        bannerUrl[i] = bannerResponse.getData()[i].getUrl();
                    }
                    infoImageTableLayout.setupWithViewPager(infoImageViewPager, true);
                    mPicPagerAdapter = new PicPagerAdapter(getActivity(), bannerImg, bannerUrl);
                    infoImageViewPager.setAdapter(mPicPagerAdapter);

                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < bannerResponse.getNotice().length; i++) {
                        sb.append(bannerResponse.getNotice()[i]);
                        sb.append("\t\t\t\t");
                    }
                    notify_tv = mView.findViewById(R.id.fragment_home_notify_tv);
                    notify_tv.setText(sb);
                }

                @Override
                public void onFail(String errorMsg, boolean shouldRetry) {
                }
            });

            drawerLayout = mView.findViewById(R.id.fragment_home_dl);
            mView.findViewById(R.id.fragment_home_fl_menu).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    drawerLayout.openDrawer(Gravity.START);
                }
            });

            mView.findViewById(R.id.fragment_home_menu_back).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    drawerLayout.closeDrawer(Gravity.START);
                }
            });

            logInOut = mView.findViewById(R.id.fragment_home_menu_login);
            if (UserInfoManager.getInstance().isLoggedIn(getActivity())) {
                logInOut.setText(getString(R.string.fragment_home_menu_logout));
            } else {
                logInOut.setText(getString(R.string.fragment_home_menu_login));
            }
            logInOut.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (logInOut.getText().equals(getString(R.string.fragment_home_menu_login))) {
                        openFragmentPage(LoginFragment.newInstance(), LoginFragment.TAG);
                    } else {
                        String loginToken = UserInfoManager.getInstance().getUserLoginToekn(getActivity());
                        IBuyBaseAPI.getInstance().logout(getActivity(), loginToken,
                                new NetworkManager.NetworkManagerListener<LogoutResponse>() {
                                    @Override
                                    public void onSucceed(LogoutResponse logoutResponse) {
                                        UserInfoManager.getInstance().userLoggedout(getActivity());
                                        EventBus.getDefault().post(new OmniEvent(OmniEvent.TYPE_LOGIN_STATUS_CHANGED, ""));
                                    }

                                    @Override
                                    public void onFail(String errorMsg, boolean shouldRetry) {
                                    }
                                });
                    }
                    drawerLayout.closeDrawer(Gravity.START);
                }
            });

            quota_tv = mView.findViewById(R.id.fragment_home_quota_content);
            bouns_tv = mView.findViewById(R.id.fragment_home_bonus_content);
            order_tv = mView.findViewById(R.id.fragment_home_order_content);

            if (UserInfoManager.getInstance().isLoggedIn(getActivity())) {
                quota_tv.setText(UserInfoManager.getInstance().getUserInfo(getActivity()).getQuota());
                bouns_tv.setText(UserInfoManager.getInstance().getUserInfo(getActivity()).getBonus());
                order_tv.setText(String.valueOf(UserInfoManager.getInstance().getUserInfo(getActivity()).getOrder_num()));
            }

            mView.findViewById(R.id.fragment_home_quota_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (UserInfoManager.getInstance().isLoggedIn(getActivity())) {
                        Intent intent = new Intent(getActivity(), WebViewActivity.class);
                        intent.putExtra(IBuyBaseText.KEY_WEB_LINK, UserInfoManager.getInstance().getUserInfo(getActivity()).getQuota_url());
                        intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.fragment_home_quota));
                        startActivity(intent);
                    } else {
                        DialogTools.getInstance().showErrorMessage(getActivity(),
                                R.string.dialog_title_text_note,
                                R.string.dialog_message_no_login,
                                new DialogInterface.OnDismissListener() {
                                    @Override
                                    public void onDismiss(DialogInterface dialog) {
                                        openFragmentPage(LoginFragment.newInstance(), LoginFragment.TAG);
                                    }
                                });
                    }
                }
            });

            mView.findViewById(R.id.fragment_home_bonus_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (UserInfoManager.getInstance().isLoggedIn(getActivity())) {
                        Intent intent = new Intent(getActivity(), WebViewActivity.class);
                        intent.putExtra(IBuyBaseText.KEY_WEB_LINK, UserInfoManager.getInstance().getUserInfo(getActivity()).getBonus_url());
                        intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.fragment_home_coupon));
                        startActivity(intent);
                    } else {
                        DialogTools.getInstance().showErrorMessage(getActivity(),
                                R.string.dialog_title_text_note,
                                R.string.dialog_message_no_login,
                                new DialogInterface.OnDismissListener() {
                                    @Override
                                    public void onDismiss(DialogInterface dialog) {
                                        openFragmentPage(LoginFragment.newInstance(), LoginFragment.TAG);
                                    }
                                });
                    }
                }
            });

            mView.findViewById(R.id.fragment_home_order_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (UserInfoManager.getInstance().isLoggedIn(getActivity())) {
                        Intent intent = new Intent(getActivity(), WebViewActivity.class);
                        intent.putExtra(IBuyBaseText.KEY_WEB_LINK, UserInfoManager.getInstance().getUserInfo(getActivity()).getOrder_url());
                        intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.fragment_home_order));
                        startActivity(intent);
                    } else {
                        DialogTools.getInstance().showErrorMessage(getActivity(),
                                R.string.dialog_title_text_note,
                                R.string.dialog_message_no_login,
                                new DialogInterface.OnDismissListener() {
                                    @Override
                                    public void onDismiss(DialogInterface dialog) {
                                        openFragmentPage(LoginFragment.newInstance(), LoginFragment.TAG);
                                    }
                                });
                    }
                }
            });

            mView.findViewById(R.id.fragment_home_shopping_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), WebViewActivity.class);
                    intent.putExtra(IBuyBaseText.KEY_WEB_LINK, "https://ibuybase.utobonus.com/product_list?level=2&id=6");
                    intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.fragment_home_recommend_shopping));
                    startActivity(intent);
                }
            });

            mView.findViewById(R.id.fragment_home_3d_store_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), WebViewActivity.class);
                    intent.putExtra(IBuyBaseText.KEY_WEB_LINK, "http://ibuybase.utobonus.com/show_case?id=1");
                    intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.fragment_home_recommend_3d_store));
                    startActivity(intent);
                }
            });

            mView.findViewById(R.id.fragment_home_traffic_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), WebViewActivity.class);
                    intent.putExtra(IBuyBaseText.KEY_WEB_LINK, "https://ereadymap.omniguider.com/transportation");
                    intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.fragment_home_recommend_traffic));
                    startActivity(intent);
                }
            });

            mView.findViewById(R.id.fragment_home_recreation_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    Intent intent = new Intent(getActivity(), WebViewActivity.class);
//                    intent.putExtra(IBuyBaseText.KEY_WEB_LINK, "https://ereadymap.omniguider.com/viewpoints");
//                    intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.fragment_home_recommend_recreation));
//                    startActivity(intent);

                    Intent intent = new Intent(getActivity(), Y5CitySDKActivity.class);
                    intent.putExtra(ARG_KEY_USER_ID, "10215018434602469");
                    intent.putExtra(ARG_KEY_USER_NAME, "Christine Chiu");
                    intent.putExtra(ARG_KEY_PROJECT_ID, "kh");
                    intent.putExtra(ARG_KEY_TYPE, "trip");
                    startActivity(intent);
                }
            });

            mView.findViewById(R.id.fragment_home_mission_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), WebViewActivity.class);
                    intent.putExtra(IBuyBaseText.KEY_WEB_LINK, "https://gpwd.mnd.gov.tw/Publish.aspx?cnid=135&p=6112");
                    intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.fragment_home_recommend_mission));
                    startActivity(intent);
                }
            });
            mView.findViewById(R.id.fragment_home_learning_fl).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openFragmentPage(LearningFragment.newInstance(), LearningFragment.TAG);
                }
            });
        }

        return mView;
    }

    public class PicPagerAdapter extends PagerAdapter {

        private Context mContext;
        private String[] picList;
        private String[] urlList;

        public PicPagerAdapter(Context mContext, String[] picList, String[] bannerUrl) {
            this.mContext = mContext;
            this.picList = picList;
            this.urlList = bannerUrl;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull final ViewGroup container, final int position) {

            LayoutInflater layoutInflater = LayoutInflater.from(mContext);
            final View layout = layoutInflater.inflate(R.layout.home_image_layout, container, false);
            final NetworkImageView imageView = layout.findViewById(R.id.home_image_layout_iv);
            NetworkManager.getInstance().setNetworkImage(mContext, imageView, picList[position]);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getActivity(), WebViewActivity.class);
                    intent.putExtra(IBuyBaseText.KEY_WEB_LINK, urlList[position]);
                    intent.putExtra(IBuyBaseText.KEY_WEB_TITLE, getResources().getString(R.string.app_name));
                    startActivity(intent);
                }
            });
            container.addView(layout);

            return layout;
        }

        @Override
        public int getCount() {
            int count = 0;
            for (int i = 0; i < picList.length; i++) {
                if (picList[i].length() != 0) {
                    count++;
                }
            }
            return count;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view == o;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return "";
        }
    }

    private void openFragmentPage(Fragment fragment, String tag) {
        AnimationFragmentManager.getInstance().addFragmentPage(getActivity(),
                R.id.activity_main_fl, fragment, tag);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}
