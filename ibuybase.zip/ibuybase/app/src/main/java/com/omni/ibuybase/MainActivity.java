package com.omni.ibuybase;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.support.annotation.StringRes;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;

import com.omni.ibuybase.tool.IBuyBaseText;
import com.omni.ibuybase.tool.Tools;
import com.omni.ibuybase.view.BlankFragment;
import com.omni.ibuybase.view.HomeFragment;

public class MainActivity extends AppCompatActivity {

    private FragmentTabHost mTabHost;
    private TabWidget mTabWidget;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ensurePermissions();

        mTabHost = findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), R.id.real_tab_content);

        mTabHost.addTab(mTabHost.newTabSpec(IBuyBaseText.TAB_NAME_HOME)
                        .setIndicator(generateTabView(R.string.activity_main_btn_home, R.mipmap.btn_home_w)),
                HomeFragment.class,
                null);

        mTabHost.addTab(mTabHost.newTabSpec(IBuyBaseText.TAB_NAME_MESSAGE)
                        .setIndicator(generateTabView(R.string.activity_main_btn_news, R.mipmap.btn_news_g)),
                HomeFragment.class,
                null);

        mTabHost.addTab(mTabHost.newTabSpec(IBuyBaseText.TAB_NAME_AR)
                        .setIndicator(generateTabView(R.string.activity_main_btn_menu, R.mipmap.btn_menu_g)),
                BlankFragment.class,
                null);

        mTabHost.addTab(mTabHost.newTabSpec(IBuyBaseText.TAB_NAME_MAP)
                        .setIndicator(generateTabView(R.string.activity_main_btn_map, R.mipmap.btn_map_g)),
                HomeFragment.class,
                null);

        mTabHost.addTab(mTabHost.newTabSpec(IBuyBaseText.TAB_NAME_MEMBER)
                        .setIndicator(generateTabView(R.string.activity_main_btn_member, R.mipmap.btn_member_g)),
                HomeFragment.class,
                null);

        mTabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @SuppressLint("ResourceAsColor")
            @Override
            public void onTabChanged(String tabId) {
                updateTabView(mTabHost);

                for (int i = 0; i < mTabHost.getTabWidget().getChildCount(); i++) {
                    mTabHost.getTabWidget().getChildAt(i)
                            .setBackgroundResource(R.color.colorPrimary); // unselected
                }

                mTabHost.getTabWidget().getChildAt(mTabHost.getCurrentTab())
                        .setBackgroundResource(R.color.colorPrimary); // selected

            }
        });

        mTabHost.onTabChanged(IBuyBaseText.TAB_NAME_HOME);

        mTabWidget = mTabHost.getTabWidget();
    }

    private View generateTabView(@StringRes int strId, @DrawableRes int iconResId) {
        TextView tv = new TextView(this);
        tv.setTextSize(12);
        tv.setHeight(Tools.getInstance().getTabBarHeight(this));
        tv.setPadding(0, Tools.getInstance().dpToIntPx(this, 10), 0, 0);
        tv.setText(getString(strId));
        tv.setGravity(Gravity.CENTER);
        tv.setCompoundDrawablesWithIntrinsicBounds(null, Tools.getInstance().getDrawable(this, iconResId), null, null);
        tv.setBackgroundResource(R.color.colorPrimary);

        return tv;
    }

    private void updateTabView(TabHost tabHost) {
        TextView tv;
        int currentIndex = tabHost.getCurrentTab();
        for (int i = 0; i < tabHost.getTabWidget().getTabCount(); i++) {
            tv = (TextView) tabHost.getTabWidget().getChildTabViewAt(i);
            tv.setTextColor(currentIndex == i ? getResources().getColor(android.R.color.white) : getResources().getColor(R.color.gray_8e));
            tv.setCompoundDrawablesWithIntrinsicBounds(null, Tools.getInstance().getDrawable(this, getTabIcon(i, (currentIndex == i))), null, null);
        }
    }

    @DrawableRes
    private int getTabIcon(int tabIndex, boolean isSelected) {
        switch (tabIndex) {
            case 0:
                return isSelected ? R.mipmap.btn_home_w : R.mipmap.btn_home_g;

            case 1:
                return isSelected ? R.mipmap.btn_news_w : R.mipmap.btn_news_g;

            case 2:
                return isSelected ? R.mipmap.btn_menu_w : R.mipmap.btn_menu_g;

            case 3:
                return isSelected ? R.mipmap.btn_map_w : R.mipmap.btn_map_g;

            case 4:
                return isSelected ? R.mipmap.btn_member_w : R.mipmap.btn_member_g;

            default:
                return isSelected ? R.mipmap.btn_home_w : R.mipmap.btn_home_g;
        }
    }

    private void ensurePermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_WIFI_STATE) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.CHANGE_WIFI_STATE) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CHANGE_WIFI_STATE,
                            Manifest.permission.ACCESS_WIFI_STATE,
                            Manifest.permission.CAMERA},
                    99);

        }
    }
}
