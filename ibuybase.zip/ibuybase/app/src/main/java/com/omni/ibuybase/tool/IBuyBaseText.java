package com.omni.ibuybase.tool;

public class IBuyBaseText {

    public static final String LOG_TAG = "IBB_LOG";

    public static final String TAB_NAME_HOME = "tab_name_home";
    public static final String TAB_NAME_MESSAGE = "tab_name_message";
    public static final String TAB_NAME_AR = "tab_name_ar";
    public static final String TAB_NAME_MAP = "tab_name_map";
    public static final String TAB_NAME_MEMBER = "tab_name_member";
    public static final String KEY_NOTIFICATION_GEOFENCE_CONTENT = "key_notification_geofence_content";
    public static final String KEY_NOTIFICATION_FIREBASE_CONTENT = "key_notification_firebase_content";

    public static final String KEY_WEB_LINK = "arg_webview_activity_link";
    public static final String KEY_WEB_TITLE = "arg_webview_activity_title";
    public static final String KEY_YOUTUBE_VIDEO_ID = "arg_youtube_video_id";
    public static final String KEY_YOUTUBE_TITLE = "arg_youtube_title";
}
