package com.omni.ibuybase.network.api;

import android.app.Activity;
import android.util.Log;

import com.omni.ibuybase.module.CommonResponse;
import com.omni.ibuybase.module.info.BannerResponse;
import com.omni.ibuybase.module.user.LoginData;
import com.omni.ibuybase.module.user.LogoutResponse;
import com.omni.ibuybase.network.NetworkManager;
import com.omni.ibuybase.tool.DialogTools;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

import static com.omni.ibuybase.tool.IBuyBaseText.LOG_TAG;

public class IBuyBaseAPI {

    private static IBuyBaseAPI mHiOneAPI;

    public static IBuyBaseAPI getInstance() {
        if (mHiOneAPI == null) {
            mHiOneAPI = new IBuyBaseAPI();
        }
        return mHiOneAPI;
    }

    interface HiOneService {

        @FormUrlEncoded
        @POST("api/login")
        Call<CommonResponse> login(@Field("account") String account,
                                   @Field("password") String password,
                                   @Field("device_id") String deviceId,
                                   @Field("timestamp") String timestamp,
                                   @Field("mac") String mac);

        @FormUrlEncoded
        @POST("api/logout")
        Call<LogoutResponse> logout(@Field("login_token") String loginToken,
                                    @Field("device_id") String deviceId,
                                    @Field("timestamp") String timestamp,
                                    @Field("mac") String mac);

        @FormUrlEncoded
        @POST("api/get_banner")
        Call<BannerResponse> getBanner(
                @Field("timestamp") String timestamp,
                @Field("mac") String mac);
    }

    private HiOneService getHiOneService() {
        return NetworkManager.getInstance().getRetrofit().create(HiOneService.class);
    }

    public void login(Activity activity, String account, String password, NetworkManager.NetworkManagerListener<LoginData> listener) {

        DialogTools.getInstance().showProgress(activity);

        long currentTimestamp = System.currentTimeMillis() / 1000L;
        String mac = NetworkManager.getInstance().getMacStr(currentTimestamp);
        Log.e(LOG_TAG,"password"+password);
        Call<CommonResponse> call = getHiOneService().login(account,
                password,
                NetworkManager.getInstance().getDeviceId(activity),
                currentTimestamp + "",
                mac);

        NetworkManager.getInstance().addPostRequestToCommonObj(activity, call, LoginData.class, listener);
    }

    public void logout(Activity activity, String loginToken, NetworkManager.NetworkManagerListener<LogoutResponse> listener) {

        DialogTools.getInstance().showProgress(activity);

        long currentTimestamp = System.currentTimeMillis() / 1000L;
        String mac = NetworkManager.getInstance().getMacStr(currentTimestamp);

        Call<LogoutResponse> call = getHiOneService().logout(loginToken,
                NetworkManager.getInstance().getDeviceId(activity),
                currentTimestamp + "",
                mac);

        NetworkManager.getInstance().addPostRequest(activity, call, LogoutResponse.class, listener);
    }

    public void getBanner(Activity activity, NetworkManager.NetworkManagerListener<BannerResponse> listener) {

        long currentTimestamp = System.currentTimeMillis() / 1000L;
        String mac = NetworkManager.getInstance().getMacStr(currentTimestamp);

        Call<BannerResponse> call = getHiOneService().getBanner(currentTimestamp + "", mac);

        NetworkManager.getInstance().addPostRequest(activity, call, BannerResponse.class, listener);
    }


}
