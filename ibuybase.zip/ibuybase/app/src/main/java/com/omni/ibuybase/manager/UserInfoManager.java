package com.omni.ibuybase.manager;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import com.omni.ibuybase.R;
import com.omni.ibuybase.module.user.LoginData;
import com.omni.ibuybase.module.user.UserLoginInfo;
import com.omni.ibuybase.network.NetworkManager;
import com.omni.ibuybase.tool.DialogTools;
import com.omni.ibuybase.tool.PreferencesTools;

import static com.omni.ibuybase.tool.IBuyBaseText.LOG_TAG;

public class UserInfoManager {

    private static UserInfoManager sUserInfoManager;

    public static final String KEY_USER_LOGIN_INFO = "key_preferences_user_login_info";

    public static UserInfoManager getInstance() {
        if (sUserInfoManager == null) {
            sUserInfoManager = new UserInfoManager();
        }

        return sUserInfoManager;
    }

    public boolean isLoggedIn(Activity activity) {
        UserLoginInfo userLoginInfo = getUserInfo(activity);
        if (userLoginInfo != null) {
            Log.e(LOG_TAG, "login token : " + userLoginInfo.getLogin_token() + ", deviceId : " + NetworkManager.getInstance().getDeviceId(activity));
        }
        Log.e(LOG_TAG, "isLoggedIn : " + String.valueOf(userLoginInfo != null && !TextUtils.isEmpty(userLoginInfo.getLogin_token())));
        return userLoginInfo != null && !TextUtils.isEmpty(userLoginInfo.getLogin_token());
    }

    public void saveUserLoginInfo(Activity activity, LoginData data) {
        UserLoginInfo userLoginInfo = getUserInfo(activity);
        if (userLoginInfo == null) {
            userLoginInfo = new UserLoginInfo.Builder().build();
        }
        userLoginInfo.setAccount(data.getAccount());
        userLoginInfo.setLogin_token(data.getLogin_token());
        userLoginInfo.setName(data.getName());
        userLoginInfo.setNickname(data.getNickname());
        userLoginInfo.setBonus(data.getBonus());
        userLoginInfo.setBonus_url(data.getBonus_url());
        userLoginInfo.setQuota(data.getQuota());
        userLoginInfo.setQuota_url(data.getQuota_url());
        userLoginInfo.setOrder_num(data.getOrder_num());
        userLoginInfo.setOrder_url(data.getOrder_url());

        PreferencesTools.getInstance().saveProperty(activity, KEY_USER_LOGIN_INFO, userLoginInfo);
    }

    public void updateUserLoginToken(Activity activity, String loginToken) {
        UserLoginInfo userLoginInfo = getUserInfo(activity);
        if (userLoginInfo == null) {
            return;
        }

        userLoginInfo.setLogin_token(loginToken);

        PreferencesTools.getInstance().saveProperty(activity, KEY_USER_LOGIN_INFO, userLoginInfo);
    }

    public void userLoggedout(Activity activity) {
        PreferencesTools.getInstance().removeProperty(activity, KEY_USER_LOGIN_INFO);
    }

    @Nullable
    public UserLoginInfo getUserInfo(Activity activity) {
        return PreferencesTools.getInstance().getProperty(activity, KEY_USER_LOGIN_INFO, UserLoginInfo.class);
    }

    @NonNull
    public String getUserLoginToekn(Activity activity) {
        UserLoginInfo loginInfo = getUserInfo(activity);
        if (loginInfo == null) {
            DialogTools.getInstance().showErrorMessage(activity, R.string.dialog_title_text_note, R.string.dialog_message_no_login);
            return null;
        } else {
            String loginToken = loginInfo.getLogin_token();
            if (TextUtils.isEmpty(loginToken)) {

                DialogTools.getInstance().showErrorMessage(activity, R.string.dialog_title_text_note, R.string.dialog_message_no_login);
                return null;
            } else {
                return loginToken;
            }
        }
    }
}
