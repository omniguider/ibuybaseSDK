package com.omni.ibuybase.module.user;

import android.util.Base64;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class UserLoginInfo implements Serializable {

    private String account;
    private String login_token;
    private String name;
    private String nickname;
    private String bonus;
    private String bonus_url;
    private String quota;
    private String quota_url;
    private int order_num;
    private String order_url;

    private final static String IvAES = "ogamin://omoapp";
    private final static String KeyAES = "omoapp://ogaminomoapp://ogamin";

    public static class Builder {

        private UserLoginInfo mUserLoginInfo;

        public Builder() {
            if (mUserLoginInfo == null) {
                mUserLoginInfo = new UserLoginInfo();
            }
        }

        public UserLoginInfo build() {
            return mUserLoginInfo;
        }

        public Builder setAccount(String account) {
            mUserLoginInfo.setAccount(account);
            return this;
        }

        public Builder setLogin_token(String login_token) {
            mUserLoginInfo.setLogin_token(login_token);
            return this;
        }

        public Builder setName(String name) {
            mUserLoginInfo.setName(name);
            return this;
        }

        public Builder setNickname(String nickname) {
            mUserLoginInfo.setNickname(nickname);
            return this;
        }

        public Builder setBonus(String bonus) {
            mUserLoginInfo.setBonus(bonus);
            return this;
        }

        public Builder setBonus_url(String bonus_url) {
            mUserLoginInfo.setBonus_url(bonus_url);
            return this;
        }

        public Builder setQuota(String quota) {
            mUserLoginInfo.setQuota(quota);
            return this;
        }

        public Builder setQuota_url(String quota_url) {
            mUserLoginInfo.setQuota_url(quota_url);
            return this;
        }

        public Builder setOrder_num(int order_num) {
            mUserLoginInfo.setOrder_num(order_num);
            return this;
        }

        public Builder setOrder_url(String order_url) {
            mUserLoginInfo.setOrder_url(order_url);
            return this;
        }
    }

    private UserLoginInfo() {

    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getLogin_token() {
        return login_token;
    }

    public void setLogin_token(String login_token) {
        this.login_token = login_token;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getBonus() {
        return bonus;
    }

    public void setBonus(String bonus) {
        this.bonus = bonus;
    }

    public String getBonus_url() {
        return bonus_url;
    }

    public void setBonus_url(String bonus_url) {
        this.bonus_url = bonus_url;
    }

    public String getQuota() {
        return quota;
    }

    public void setQuota(String quota) {
        this.quota = quota;
    }

    public String getQuota_url() {
        return quota_url;
    }

    public void setQuota_url(String quota_url) {
        this.quota_url = quota_url;
    }

    public int getOrder_num() {
        return order_num;
    }

    public void setOrder_num(int order_num) {
        this.order_num = order_num;
    }

    public String getOrder_url() {
        return order_url;
    }

    public void setOrder_url(String order_url) {
        this.order_url = order_url;
    }

    private static byte[] EncryptAES(byte[] iv, byte[] key, byte[] text) {
        try {
            AlgorithmParameterSpec mAlgorithmParameterSpec = new IvParameterSpec(iv);
            SecretKeySpec mSecretKeySpec = new SecretKeySpec(key, "AES");
            Cipher mCipher = null;
            mCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            mCipher.init(Cipher.ENCRYPT_MODE, mSecretKeySpec, mAlgorithmParameterSpec);

            return mCipher.doFinal(text);
        } catch (Exception ex) {
            return null;
        }
    }

    private static byte[] DecryptAES(byte[] iv, byte[] key, byte[] text) {
        try {
            AlgorithmParameterSpec mAlgorithmParameterSpec = new IvParameterSpec(iv);
            SecretKeySpec mSecretKeySpec = new SecretKeySpec(key, "AES");
            Cipher mCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            mCipher.init(Cipher.DECRYPT_MODE,
                    mSecretKeySpec,
                    mAlgorithmParameterSpec);

            return mCipher.doFinal(text);
        } catch (Exception ex) {
            return null;
        }
    }

    private String encrypt(String encrypt) {
        String encrypt_String = "";
        try {
            if (encrypt != null) {
                byte[] TextByte = EncryptAES(IvAES.getBytes("UTF-8"), KeyAES.getBytes("UTF-8"), encrypt.getBytes("UTF-8"));
                encrypt_String = Base64.encodeToString(TextByte, Base64.DEFAULT);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return encrypt_String;
    }

    private String decrypt(String decrypt) {
        String decrypt_String = "";
        try {
            if (decrypt != null) {
                byte[] TextByte = DecryptAES(IvAES.getBytes("UTF-8"), KeyAES.getBytes("UTF-8"), Base64.decode(decrypt.getBytes("UTF-8"), Base64.DEFAULT));
                if (TextByte != null) {
                    decrypt_String = new String(TextByte, "UTF-8");
                }
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return decrypt_String;
    }
}
